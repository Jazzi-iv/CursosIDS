package com.microservicios.curso.Login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
